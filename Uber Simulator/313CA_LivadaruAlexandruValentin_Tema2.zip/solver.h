// Copyright 2019 SD_Homework_Team
// Copyright[2019] <Livadaru Alexandru-Valentin 313CA>

#ifndef SOLVER_H_
#define SOLVER_H_
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <iterator>
#include <queue>
#include "./graph.h"
#include "./hashtable.h"

class solver {
	private:
		int N, M;
		Dictionary<std::string, int> uber_hashtable;
		Graph<int> uber_graph;

	public:
		void task1_solver(std::ifstream& fin, std::ofstream& fout) {
			int Q1;
			int index1, index2, location, destination;
			fin >> N >> M;
			uber_hashtable.alloc_memory(N);
			uber_graph.set_size(N);
			std::string pair1, pair2, start, end;
			std::string text;
			for (int i = 0; i < N; ++i){
				fin >> text;
				uber_hashtable.insert(text, i);
			}
			for (int i = 0; i < M; ++i) {
				fin >> pair1 >> pair2;
				index1 = uber_hashtable.get(pair1);
				index2 = uber_hashtable.get(pair2);
				uber_graph.addEdge(index1, index2);
			}
			fin >> Q1;
			for (int i = 0; i < Q1; ++i) {
				fin >> start >> end;
				location = uber_hashtable.get(start);
				destination = uber_hashtable.get(end);
				if (uber_graph.BFS(location, destination, N) != -1) {
					fout << "y" << "\n";
				} else {
					fout << "n" << "\n";
				}
			}
		}

		void task2_solver(std::ifstream& fin, std::ofstream& fout) {
			int Q2, coord1, coord2;
			std::string location1, location2;
			fin >> Q2;
			for (int i = 0; i < Q2; ++i) {
				fin >> location1 >> location2;
				coord1 = uber_hashtable.get(location1);
				coord2 = uber_hashtable.get(location2);
				fout << uber_graph.BFS(coord1, coord2, N) << "\n";
			}
		}

		void task3_solver(std::ifstream& fin, std::ofstream& fout) {
			int Q3, index1, index2, grade;
			char type;
			std::string loc1, loc2, loc3;
			fin >> Q3;
			for (int i = 0; i < Q3; ++i) {
				fin >> type >> loc1 >> loc2 >> grade;
				index1 = uber_hashtable.get(loc1);
				index2 = uber_hashtable.get(loc2);
				if (type == 'c') {
					if (grade == 0) {
						uber_graph.addEdge(index1, index2);
					}
					if (grade == 1) {
						uber_graph.removeEdge(index1, index2);
						uber_graph.removeEdge(index2, index1);
					}
					if (grade == 2) {
						uber_graph.addEdge(index1, index2);
						uber_graph.addEdge(index2, index1);
					}
					if (grade == 3) {
						bool modification = 0;
						if (uber_graph.hasEdge(index1, index2) == 1 &&
						uber_graph.hasEdge(index2, index1) == 0) {
							uber_graph.removeEdge(index1, index2);
							uber_graph.addEdge(index2, index1);
							modification = 1;
						}
						if (uber_graph.hasEdge(index2, index1) == 1 &&
						uber_graph.hasEdge(index1, index2) == 0 && modification == 0) {
							uber_graph.removeEdge(index2, index1);
							uber_graph.addEdge(index1, index2);
						}
					}
				}
				if (type == 'q') {
					if (grade == 0) {
						if (uber_graph.BFS(index1, index2, N) != -1) {
							fout << "y" << "\n";
						} else {
							fout << "n" << "\n";
						}
					}
					if (grade == 1) {
						fout << uber_graph.BFS(index1, index2, N) << "\n";
					}
					if (grade == 2) {
						int a, index3, b;
						fin >> loc3;
						index3 = uber_hashtable.get(loc3);
						a = uber_graph.BFS(index1, index3, N);
						b = uber_graph.BFS(index3, index2, N);
						if (a == -1 || b == -1) {
							fout << "-1\n";
						} else {
							fout << (a + b) << "\n";
						}
					}
				}
			}
		}

		void task4_solver(std::ifstream& fin, std::ofstream& fout) {
			int Q4;
			fin >> Q4;
			fout << ".";
		}

		void task5_solver(std::ifstream& fin, std::ofstream& fout) {
			int Q5;
			fin >> Q5;
			fout << ".";
		}
};
#endif  // SOLVER_H_
